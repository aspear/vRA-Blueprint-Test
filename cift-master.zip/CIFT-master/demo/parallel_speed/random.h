#ifndef RANDOM_INCLUDED
#define RANDOM_INCLUDED

int random(unsigned int max);

#endif


#ifndef CHECK_DECK_INCLUDED
#define CHECK_DECK_INCLUDED

// #include <varargs.h>
#include "deck.h"
#include "stack_of_cards.h"


bool check_deck(int bogus, ...);

#endif

